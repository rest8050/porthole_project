import sqlite3
from contextlib import closing, contextmanager
from pathlib import Path


DB_PATH = Path(__file__).resolve().parent / "data" / "images.sqlite3"


@contextmanager
def connect():
    with closing(sqlite3.connect(DB_PATH, timeout=15)) as db:
        with db:
            yield db


def initialize():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("""
            CREATE TABLE IF NOT EXISTS images (
                image_id TEXT PRIMARY KEY NOT NULL,
                media_type TEXT NOT NULL,
                content BLOB NOT NULL,
                saved INTEGER NOT NULL DEFAULT 0 CHECK (saved IN (0, 1))
            )
        """)


def receive_many(images: list[tuple[str, str, bytes]]) -> list[bool]:
    inserted = []

    with connect() as db:
        for image in images:
            result = db.execute(
                """
                INSERT INTO images (image_id, media_type, content)
                VALUES (?, ?, ?)
                ON CONFLICT(image_id) DO NOTHING
                """,
                image,
            )
            inserted.append(result.rowcount == 1)

    return inserted


def save(image_id: str) -> bool:
    with connect() as db:
        result = db.execute(
            "UPDATE images SET saved = 1 WHERE image_id = ?",
            (image_id,),
        )
        return result.rowcount == 1


def get_saved(image_id: str) -> tuple[str, bytes] | None:
    with connect() as db:
        return db.execute(
            """
            SELECT media_type, content
            FROM images
            WHERE image_id = ? AND saved = 1
            """,
            (image_id,),
        ).fetchone()