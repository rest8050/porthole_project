from hashlib import sha256
from io import BytesIO
from typing import BinaryIO
from zipfile import BadZipFile, ZIP_DEFLATED, ZIP_STORED, ZipFile
from zlib import error as ZlibError

from PIL import Image, UnidentifiedImageError

import repository


MAX_ZIP_BYTES = 25 * 1024          # 업로드하는 ZIP 자체의 최대 크기
MAX_BYTES = 10 * 1024 * 1024       # 압축 해제 후 이미지 파일 크기의 합계
MAX_PIXELS = 25_000_000            # 요청 한 건에 포함된 이미지의 총 픽셀 수
MEDIA_TYPES = {"JPEG": "image/jpeg", "PNG": "image/png"}


class TooLarge(ValueError):
    pass


class InvalidArchive(ValueError):
    pass


def inspect_image(content: bytes, available_pixels: int) -> tuple[str, int]:
    """실제 파일 형식과 픽셀 데이터를 검사합니다."""
    try:
        with Image.open(BytesIO(content), formats=list(MEDIA_TYPES)) as img:
            pixels = img.width * img.height
            if pixels > available_pixels:
                raise TooLarge("한 요청에서 총 2,500만 픽셀까지 수신할 수 있습니다.")

            media_type = MEDIA_TYPES[img.format]
            img.verify()

        # verify() 후 파일을 다시 열어 픽셀 데이터도 읽히는지 확인합니다.
        with Image.open(BytesIO(content), formats=list(MEDIA_TYPES)) as img:
            img.load()

    except Image.DecompressionBombError as exc:
        raise TooLarge("이미지의 픽셀 수가 너무 큽니다.") from exc
    except (UnidentifiedImageError, OSError, SyntaxError) as exc:
        raise ValueError("올바른 JPEG 또는 PNG 파일을 보내 주세요.") from exc

    return media_type, pixels


def receive_zip(stream: BinaryIO) -> dict:
    compressed = stream.read(MAX_ZIP_BYTES + 1)
    if len(compressed) > MAX_ZIP_BYTES:
        raise TooLarge("ZIP 파일은 25,600바이트까지 업로드할 수 있습니다.")

    names = []
    images = []
    remaining_bytes = MAX_BYTES
    remaining_pixels = MAX_PIXELS

    try:
        with ZipFile(BytesIO(compressed)) as archive:
            for member in archive.infolist():
                if member.is_dir():
                    continue

                if member.flag_bits & 1:
                    raise InvalidArchive("암호가 설정된 ZIP은 처리할 수 없습니다.")

                if member.compress_type not in (ZIP_STORED, ZIP_DEFLATED):
                    raise InvalidArchive("ZIP 압축 방식은 Store 또는 Deflate를 사용하세요.")

                if member.file_size > remaining_bytes:
                    raise TooLarge("압축 해제된 파일의 합계는 10 MiB까지 허용됩니다.")

                # 내부 경로를 디스크에 생성하지 않고 메모리에서 읽습니다.
                with archive.open(member) as entry:
                    content = entry.read(remaining_bytes + 1)

                if len(content) > remaining_bytes:
                    raise TooLarge("압축 해제된 파일의 합계는 10 MiB까지 허용됩니다.")

                media_type, pixels = inspect_image(content, remaining_pixels)
                remaining_bytes -= len(content)
                remaining_pixels -= pixels

                image_id = sha256(content).hexdigest()
                names.append(member.filename)
                images.append((image_id, media_type, content))

    except (BadZipFile, ZlibError, EOFError, NotImplementedError, UnicodeDecodeError) as exc:
        raise InvalidArchive("ZIP 파일이 손상되었거나 지원하지 않는 형식입니다.") from exc

    if not images:
        raise InvalidArchive("ZIP 안에 업로드할 이미지가 없습니다.")

    # 모든 파일이 검증된 뒤 DB에 한 번에 반영합니다.
    inserted = repository.receive_many(images)

    return {
        "files": [
            {"filename": name, "image_id": image[0], "duplicate": not created}
            for name, image, created in zip(names, images, inserted)
        ]
    }


def receive(stream: BinaryIO, filename: str, content_type: str) -> dict:
    signature = stream.read(4)
    stream.seek(0)

    is_zip = (
        filename.lower().endswith(".zip")
        or content_type in {"application/zip", "application/x-zip-compressed"}
        or signature in {b"PK\x03\x04", b"PK\x05\x06"}
    )
    if is_zip:
        return receive_zip(stream)

    content = stream.read(MAX_BYTES + 1)
    if len(content) > MAX_BYTES:
        raise TooLarge("이미지는 10 MiB까지 수신할 수 있습니다.")

    media_type, _ = inspect_image(content, MAX_PIXELS)
    image_id = sha256(content).hexdigest()
    inserted = repository.receive_many([(image_id, media_type, content)])

    return {"image_id": image_id, "duplicate": not inserted[0]}


def save(image_id: str):
    if not repository.save(image_id):
        raise KeyError(image_id)


def send(image_id: str) -> tuple[str, bytes]:
    row = repository.get_saved(image_id)
    if row is None:
        raise KeyError(image_id)
    return row