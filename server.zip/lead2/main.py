from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Response, UploadFile

import repository
import service


@asynccontextmanager
async def lifespan(app: FastAPI):
    repository.initialize()
    yield


app = FastAPI(title="이미지 서버", lifespan=lifespan)


@app.post("/images/receive", summary="이미지 수신")
def receive(file: UploadFile):
    try:
        image_id, duplicate = service.receive(file.file)
    except service.TooLarge as exc:
        raise HTTPException(413, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(415, str(exc)) from exc

    return {"image_id": image_id, "duplicate": duplicate}


@app.post("/images/receive", summary="이미지 또는 ZIP 수신")
def receive(file: UploadFile):
    try:
        return service.receive(
            stream=file.file,
            filename=file.filename or "",
            content_type=file.content_type or "",
        )
    except service.TooLarge as exc:
        raise HTTPException(status_code=413, detail=str(exc)) from exc
    except service.InvalidArchive as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=415, detail=str(exc)) from exc


@app.get(
    "/images/{image_id}/send",
    summary="원본 이미지 송신",
    response_class=Response,
    responses={200: {"content": {"image/jpeg": {}, "image/png": {}}}},
)
def send(image_id: str):
    try:
        media_type, content = service.send(image_id)
    except KeyError as exc:
        raise HTTPException(404, "저장이 확정된 이미지가 없습니다.") from exc

    return Response(content=content, media_type=media_type)