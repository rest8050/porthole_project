from datetime import datetime
from typing import Annotated, Any
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

Key = Annotated[
    str,
    StringConstraints(strip_whitespace=True, min_length=1, max_length=200),
]


class DataInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: Key
    external_id: Key
    payload: dict[str, Any]


class DataRecord(DataInput):
    id: int
    created_at: datetime


class SaveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    items: list[DataInput] = Field(min_length=1, max_length=1000)


class SaveResult(BaseModel):
    inserted: int
    duplicates: int
    items: list[DataRecord]
