import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse

from app.routers.drive_router import router as drive_router

from app.repositories.data_repository import DataRepository
from app.routers.data_router import router
from app.services.data_service import DataService
from app.routers.image_router import router as image_router



INDEX_FILE = Path(__file__).resolve().parent / "index.html"


def create_app(db_path: str | None = None) -> FastAPI:
    repository = DataRepository(
        db_path or os.getenv("DB_PATH", "./data/server.db")
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        repository.initialize()
        app.state.data_service = DataService(repository)
        yield

    application = FastAPI(
        title="Data Server",
        version="1.0.0",
        lifespan=lifespan,
    )

    application.include_router(router)
    application.include_router(image_router)
    application.include_router(drive_router)

    @application.get("/", response_class=FileResponse, include_in_schema=False)
    def home():
        return FileResponse(INDEX_FILE, media_type="text/html")

    return application


app = create_app()