from app.repositories.data_repository import DataRepository
from app.schemas import DataInput, SaveResult


class DataService:
    def __init__(self, repository: DataRepository):
        self.repository = repository

    def save(self, items: list[DataInput]) -> SaveResult:
        inserted, records = self.repository.save(items)
        return SaveResult(
            inserted=inserted,
            duplicates=len(items) - inserted,
            items=records,
        )

    def send(self, source: str | None, limit: int, offset: int):
        return self.repository.find(source, limit, offset)
