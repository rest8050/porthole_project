import io
import zipfile

from googleapiclient.errors import HttpError

from app.services.image_service import ImageService


class DriveService:
    def __init__(self, drive_repository, image_repository):
        self.drive_repository = drive_repository
        self.image_service = ImageService(image_repository)

    def sync(self, page_token=None):
        page = self.drive_repository.list_zips(page_token)

        results = []
        saved = 0
        duplicates = 0

        for file_info in page.get("files", []):
            item = {
                "drive_file_id": file_info["id"],
                "filename": file_info["name"],
            }

            try:
                content = self.drive_repository.download(file_info)

                if not zipfile.is_zipfile(io.BytesIO(content)):
                    raise ValueError(
                        "파일 내용이 정상적인 ZIP 형식이 아닙니다."
                    )

                result = self.image_service.save([
                    (file_info["name"], content)
                ])

                saved += result["saved"]
                duplicates += result["duplicates"]

                item.update({
                    "status": "completed",
                    **result,
                })

            except ValueError as exc:
                item.update({
                    "status": "failed",
                    "error": str(exc),
                })

            except HttpError as exc:
                item.update({
                    "status": "failed",
                    "error": (
                        "Drive 다운로드 실패: "
                        f"HTTP {exc.resp.status}"
                    ),
                })

            results.append(item)

        return {
            "processed_zip_count": len(results),
            "failed_zip_count": sum(
                item["status"] == "failed"
                for item in results
            ),
            "saved": saved,
            "duplicates": duplicates,
            "next_page_token": page.get("nextPageToken"),
            "files": results,
        }