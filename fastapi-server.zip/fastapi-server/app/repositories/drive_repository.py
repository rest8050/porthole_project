import io
import os

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload


MAX_ZIP_SIZE = 40 * 1024 * 1024


class LimitedBuffer(io.BytesIO):
    def write(self, data):
        if self.tell() + len(data) > MAX_ZIP_SIZE:
            raise ValueError("ZIP 파일은 최대 40MB까지 가능합니다.")
        return super().write(data)


class DriveRepository:
    def __init__(self):
        credentials_path = os.environ.get(
            "GOOGLE_APPLICATION_CREDENTIALS"
        )
        self.folder_id = os.environ.get("GOOGLE_DRIVE_FOLDER_ID")

        if not credentials_path or not self.folder_id:
            raise ValueError("Google Drive 환경변수를 설정하세요.")

        # Drive 검색 조건에 사용할 폴더 ID를 검증합니다.
        if not all(
            char.isalnum() or char in "_-"
            for char in self.folder_id
        ):
            raise ValueError("Drive 폴더 ID가 올바르지 않습니다.")

        credentials = service_account.Credentials.from_service_account_file(
            credentials_path,
            scopes=[
                "https://www.googleapis.com/auth/drive.readonly"
            ],
        )

        self.client = build(
            "drive",
            "v3",
            credentials=credentials,
            cache_discovery=False,
        )

    def list_zips(self, page_token=None):
        query = (
            f"'{self.folder_id}' in parents "
            "and trashed = false "
            "and mimeType != 'application/vnd.google-apps.folder' "
            "and ("
            "mimeType = 'application/zip' "
            "or mimeType = 'application/x-zip-compressed' "
            "or name contains '.zip' "
            "or name contains '.ZIP'"
            ")"
        )

        return self.client.files().list(
            q=query,
            pageSize=40,
            pageToken=page_token,
            fields="nextPageToken,files(id,name,size)",
            orderBy="name",
            supportsAllDrives=True,
            includeItemsFromAllDrives=True,
        ).execute(num_retries=2)

    def download(self, file_info):
        size = file_info.get("size")

        if size is not None and int(size) > MAX_ZIP_SIZE:
            raise ValueError("ZIP 파일은 최대 40MB까지 가능합니다.")

        request = self.client.files().get_media(
            fileId=file_info["id"],
            supportsAllDrives=True,
        )

        buffer = LimitedBuffer()

        downloader = MediaIoBaseDownload(
            buffer,
            request,
            chunksize=1024 * 1024,
        )

        done = False
        while not done:
            _, done = downloader.next_chunk(num_retries=2)

        return buffer.getvalue()