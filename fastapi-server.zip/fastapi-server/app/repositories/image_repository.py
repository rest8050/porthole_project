import sqlite3


class ImageRepository:
    def __init__(self, db_path):
        self.db_path = db_path

    def save(self, images):
        saved = 0
        results = []

        with sqlite3.connect(self.db_path, timeout=30) as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS images (
                    id INTEGER PRIMARY KEY,
                    sha256 TEXT NOT NULL UNIQUE,
                    filename TEXT NOT NULL,
                    media_type TEXT NOT NULL,
                    content BLOB NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            """)

            for digest, filename, media_type, content in images:
                cursor = db.execute(
                    """
                    INSERT INTO images(
                        sha256, filename, media_type, content
                    )
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(sha256) DO NOTHING
                    """,
                    (digest, filename, media_type, content),
                )

                created = cursor.rowcount == 1
                saved += int(created)

                image_id = db.execute(
                    "SELECT id FROM images WHERE sha256 = ?",
                    (digest,),
                ).fetchone()[0]

                results.append({
                    "id": image_id,
                    "filename": filename,
                    "status": "saved" if created else "duplicate",
                })

        return {
            "saved": saved,
            "duplicates": len(images) - saved,
            "items": results,
        }

    def get(self, image_id):
        with sqlite3.connect(self.db_path, timeout=30) as db:
            return db.execute(
                "SELECT content, media_type FROM images WHERE id = ?",
                (image_id,),
            ).fetchone()

    def list_images(self, limit=24, offset=0):
        # 첫 업로드 전에도 목록 조회가 가능하도록 테이블을 준비합니다.
        self.save([])

        with sqlite3.connect(self.db_path, timeout=30) as db:
            db.row_factory = sqlite3.Row

            total = db.execute(
                "SELECT COUNT(*) FROM images"
            ).fetchone()[0]

            rows = db.execute(
                """
                SELECT
                    id,
                    filename,
                    media_type,
                    length(content) AS size_bytes,
                    created_at
                FROM images
                ORDER BY id DESC
                LIMIT ? OFFSET ?
                """,
                (limit, offset),
            ).fetchall()

        return {
            "total": total,
            "items": [dict(row) for row in rows],
        }