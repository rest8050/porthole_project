import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from app.schemas import DataInput, DataRecord


class DataRepository:
    def __init__(self, db_path: str):
        self.db_path = db_path

    @contextmanager
    def connection(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def initialize(self):
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    external_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT (
                        strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
                    ),
                    UNIQUE(source, external_id)
                )
            """)

    @staticmethod
    def to_record(row):
        data = dict(row)
        data["payload"] = json.loads(data["payload"])
        return DataRecord(**data)

    def save(self, items: list[DataInput]):
        inserted = 0
        records = []

        # 배치 전체를 하나의 트랜잭션으로 처리합니다.
        with self.connection() as conn:
            for item in items:
                cursor = conn.execute(
                    "INSERT INTO records(source, external_id, payload) "
                    "VALUES (?, ?, ?) "
                    "ON CONFLICT(source, external_id) DO NOTHING",
                    (
                        item.source,
                        item.external_id,
                        json.dumps(
                            item.payload,
                            ensure_ascii=False,
                            allow_nan=False,
                        ),
                    ),
                )
                inserted += cursor.rowcount
                row = conn.execute(
                    "SELECT * FROM records "
                    "WHERE source = ? AND external_id = ?",
                    (item.source, item.external_id),
                ).fetchone()
                records.append(self.to_record(row))

        return inserted, records

    def find(self, source: str | None, limit: int, offset: int):
        with self.connection() as conn:
            if source is None:
                rows = conn.execute(
                    "SELECT * FROM records ORDER BY id LIMIT ? OFFSET ?",
                    (limit, offset),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM records WHERE source = ? "
                    "ORDER BY id LIMIT ? OFFSET ?",
                    (source, limit, offset),
                ).fetchall()

        return [self.to_record(row) for row in rows]
