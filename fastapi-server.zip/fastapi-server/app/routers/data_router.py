from typing import Annotated
from fastapi import APIRouter, Depends, Query, Request

from app.schemas import DataInput, DataRecord, SaveRequest, SaveResult
from app.services.data_service import DataService

router = APIRouter(prefix="/api/data", tags=["data"])


def get_service(request: Request) -> DataService:
    return request.app.state.data_service


Service = Annotated[DataService, Depends(get_service)]


@router.post(
    "/receive",
    response_model=SaveResult,
    summary="단건 수신 및 저장",
)
def receive(body: DataInput, service: Service):
    return service.save([body])


@router.post(
    "/save",
    response_model=SaveResult,
    summary="여러 건 일괄 저장",
)
def save(body: SaveRequest, service: Service):
    return service.save(body.items)


@router.get(
    "/send",
    response_model=list[DataRecord],
    summary="조건 조회 후 JSON 송신",
)
def send(
    service: Service,
    source: str | None = Query(default=None, min_length=1, max_length=200),
    limit: int = Query(default=100, ge=1, le=1000),
    offset: int = Query(default=0, ge=0),
):
    return service.send(source, limit, offset)
