from fastapi import APIRouter, HTTPException, Query, Request
from google.auth.exceptions import GoogleAuthError
from googleapiclient.errors import HttpError

from app.repositories.drive_repository import DriveRepository
from app.repositories.image_repository import ImageRepository
from app.services.drive_service import DriveService


router = APIRouter(
    prefix="/api/drive",
    tags=["Google Drive"],
)


@router.post("/sync", summary="Drive ZIP 가져오기 및 이미지 DB 저장")
def sync_drive(
    request: Request,
    page_token: str | None = Query(default=None),
):
    try:
        db_path = (
            request.app.state.data_service.repository.db_path
        )

        service = DriveService(
            drive_repository=DriveRepository(),
            image_repository=ImageRepository(db_path),
        )

        return service.sync(page_token)

    except HttpError as exc:
        raise HTTPException(
            status_code=502,
            detail=(
                f"Google Drive API 오류: HTTP {exc.resp.status}. "
                "API 활성화 여부와 폴더 공유 권한을 확인하세요."
            ),
        ) from exc

    except (GoogleAuthError, OSError, ValueError) as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                "Drive 연결 설정을 확인하세요. "
                "환경변수, 인증 JSON 경로와 서비스 계정을 확인하세요."
            ),
        ) from exc