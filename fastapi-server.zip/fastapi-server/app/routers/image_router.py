from fastapi import (
    APIRouter,
    File,
    HTTPException,
    Request,
    UploadFile,
)
from fastapi.responses import Response

from app.repositories.image_repository import ImageRepository
from app.services.image_service import ImageService

from fastapi import Query


router = APIRouter(prefix="/api/images", tags=["images"])
MAX_UPLOAD = 40 * 1024 * 1024


def get_service(request):
    db_path = request.app.state.data_service.repository.db_path
    return ImageService(ImageRepository(db_path))


def process(files, request):
    uploads = []
    total = 0

    try:
        if not 1 <= len(files) <= 20:
            raise HTTPException(
                status_code=413,
                detail="요청당 업로드 파일은 최대 20개입니다.",
            )

        for upload in files:
            content = upload.file.read(MAX_UPLOAD + 1)
            total += len(content)

            if len(content) > MAX_UPLOAD or total > MAX_UPLOAD:
                raise HTTPException(
                    status_code=413,
                    detail="업로드 파일 합계는 최대 20MB입니다.",
                )

            uploads.append((
                upload.filename or "image",
                content,
            ))

        return get_service(request).save(uploads)

    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc

    finally:
        for upload in files:
            upload.file.close()


@router.post("/receive", summary="이미지 또는 ZIP 단건 수신 및 저장")
def receive(
    request: Request,
    file: UploadFile = File(...),
):
    return process([file], request)


@router.post("/save", summary="이미지 또는 ZIP 여러 개 일괄 저장")
def save(
    request: Request,
    files: list[UploadFile] = File(...),
):
    return process(files, request)


@router.get("/send/{image_id}", summary="저장된 이미지 원본 송신")
def send(image_id: int, request: Request):
    repository = get_service(request).repository

    # 최초 업로드 전에도 테이블을 준비합니다.
    repository.save([])
    row = repository.get(image_id)

    if row is None:
        raise HTTPException(
            status_code=404,
            detail="이미지가 없습니다.",
        )

    return Response(
        content=row[0],
        media_type=row[1],
        headers={"X-Content-Type-Options": "nosniff"},
    )

@router.get("/list", summary="저장된 이미지 목록")
def list_images(
    request: Request,
    limit: int = Query(default=24, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    return get_service(request).list_images(
        limit=limit,
        offset=offset,
    )