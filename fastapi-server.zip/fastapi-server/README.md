# FastAPI 데이터 서버

Python 3.10 이상이 필요합니다.

## 실행
프로젝트 루트에서:
    pip install -r requirements.txt
    python -m uvicorn app.main:app --reload

API 문서: http://127.0.0.1:8000/docs

## 3계층
- routers: HTTP 요청·응답
- services: 업무 로직
- repositories: DB 접근 및 트랜잭션

## API
- POST /api/data/receive : 단건 수신 즉시 저장
- POST /api/data/save : 여러 건 일괄 저장
- GET /api/data/send : 조건 조회 후 요청자에게 JSON 응답

송신은 외부 서버에 POST하는 방식이 아니라 HTTP 응답 방식입니다.

## 수신 본문 예시
{
  "source": "sensor-01",
  "external_id": "event-001",
  "payload": {"temperature": 23.5}
}

## 일괄 저장 본문
{"items": [수신 본문 형식의 객체, ...]}

## 조회
/api/data/send?source=sensor-01&limit=100&offset=0

source는 선택 조건입니다.
limit 기본값은 100, 최대 1000입니다.
ID 오름차순으로 반환합니다.

## DB 및 중복 처리
기본 DB: ./data/server.db
DB_PATH 환경변수로 파일 경로 변경 가능.

source와 external_id 조합이 같으면 중복입니다.
DB UNIQUE 제약으로 동시 요청에서도 중복 저장을 차단합니다.
중복이면 최초 저장된 payload를 유지합니다.
기존 외부 DB의 중복 정리 작업은 포함하지 않습니다.

저장 응답:
- inserted: 신규 저장 건수
- duplicates: 중복으로 건너뛴 건수
- items: 요청 순서에 대응하는 최종 DB 레코드

입력 오류는 HTTP 422입니다.
인증은 포함하지 않습니다.
